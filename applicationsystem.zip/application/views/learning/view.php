<h2><?php echo $title; ?></h2>


<small class="post-date">Section <?php echo $videos['section']; ?></small><br>


<div class="row post-body">

	<div class="col-lg-12 text-center">

		<iframe width="800" height="400" id="embed" src="https://www.youtube.com/embed/<?php echo $videos['url']; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

	     

	</div>

</div>

<br>



