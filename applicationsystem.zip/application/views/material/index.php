 <ul class="nav nav-tabs">
    <li class="active"><a href="">Section A</a></li>
    <li><a href="section_b">Section B</a></li>
 </ul>
     <div class="news-masonry">
                <div>
                    <div class="row mas-m">
                        <div class="col-sm-6 mas-p">
                            <div class="mas-item mas-big">
                                <figure><iframe class="videoIframe js-videoIframe" width="570" height="315" src="https://www.youtube.com/embed/UU4lC_e-FKE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen ></iframe></figure>
                                <div class="mas-text">
                                    <div class="post-cat"><a href="#">Video</a></div>
                                    <h2 class="mas-title"><a href="#">Cyanide & Happiness Compilation</a></h2>
                                    <div class="mas-details">
                                        <p></p>
                                        <a href="#" class="read-more"></a>
                                    </div>
                                </div>
                            </div>
                            <!-- /.End of masonry item -->
                        </div>
                        <div class="col-sm-6 mas-p">
                            <div class="row mas-m">
                                <div class="col-xs-6 col-sm-6 mas-p">
                                    <div class="masonry-slide1 owl-carousel owl-theme" style="opacity: 1; display: block;">
                                        <div class="owl-wrapper-outer"><div class="owl-wrapper" style="left: 0px; display: block; transition: all 1000ms ease 0s; transform: translate3d(0px, 0px, 0px);"><div class="owl-item" style="width: 282px;"><div class="item mas-m-b">
                                            <div class="mas-item masonry-sm">
                                                <figure><img src="<?php echo base_url(); ?>assets/learning/5898844fcc0a3e9932978c53a8608de6.png" class="img-responsive" width="155"  alt=""></figure>  
                                                <div class="mas-text">
                                                    <div class="post-cat"><a href="<?php echo base_url(); ?>assets/learning/385e9f000a3d25b173d87d63d4ec5f54.pdf" class="read-more">Download</a></div>
                                                    <h4 class="mas-title"><a href="#">HTML Learning Material</a></h4>
                                                    <div class="mas-details">
                                                        <p></p>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.End of masonry item -->
                                        </div></div>
                    </div></div>
                                        
                                    </div>
                                </div>
                                <div class="col-xs-6 col-sm-6 mas-p">
                                    <div class="masonry-sm owl-carousel owl-theme" style="opacity: 1; display: block;">
                                        <div class="owl-wrapper-outer"><div class="owl-wrapper" style="left: 0px; display: block; transition: all 1000ms ease 0s; transform: translate3d(0px, 0px, 0px);"><div class="owl-item" style="width: 282px;"><div class="item">
                                            <div class="mas-item masonry-sm">
                                              <figure><iframe class="videoIframe js-videoIframe" src="https://www.youtube.com/embed/7v3G-m_ONNo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen ></iframe></figure>
                                                <div class="mas-text">
                                                    <div class="post-cat"><a href="#">Video</a></div>
                                                    <h4 class="mas-title"><a href="#">Cyanide & Happiness - Staring Contest & Werewolf </a></h4>
                                                    <div class="mas-details">
                                                        <p></p>
                                                        <a href="#" class="read-more"></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.End of masonry item -->
                                        </div></div></div></div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="row mas-m">
                                <div class="col-xs-6 col-sm-6 mas-p">
                                    <div class="masonry-slide1 owl-carousel owl-theme" style="opacity: 1; display: block;">
                                        <div class="owl-wrapper-outer"><div class="owl-wrapper" style=" left: 0px; display: block; transition: all 1000ms ease 0s; transform: translate3d(0px, 0px, 0px);"><div class="owl-item" style="width: 282px;"><div class="item mas-m-b">
                                            <div class="mas-item masonry-sm">
                                                <figure><img src="<?php echo base_url(); ?>assets/learning/b4eb379c53c6f479f486bbba30851ca2.png" class="img-responsive" width="110" alt=""></figure>  
                                                <div class="mas-text">
                                                    <div class="post-cat"><a href="<?php echo base_url(); ?>assets/learning/385e9f000a3d25b173d87d63d4ec5f54.pdf" class="read-more">Download</a></div>
                                                    <h4 class="mas-title"><a href="#">JS Learning Materials</a></h4>
                                                    <div class="mas-details">
                                                        <p></p>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.End of masonry item -->
                                        </div></div>
                    </div></div>
                                        
                                    </div>
                                </div>
                                <div class="col-xs-6 col-sm-6 mas-p">
                                    <div class="masonry-sm owl-carousel owl-theme" style="opacity: 1; display: block;">
                                        <div class="owl-wrapper-outer"><div class="owl-wrapper" style=" left: 0px; display: block; transition: all 1000ms ease 0s; transform: translate3d(0px, 0px, 0px);"><div class="owl-item" style="width: 282px;"><div class="item">
                                            <div class="mas-item masonry-sm">
                                                <figure><iframe class="videoIframe js-videoIframe" src="https://www.youtube.com/embed/5Ez2NXOX9zY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen ></iframe></figure>
                                                <div class="mas-text">
                                                    <div class="post-cat"><a href="#">Video</a></div>
                                                    <h4 class="mas-title"><a href="#">Django Tutorial for Beginners </a></h4>
                                                    <div class="mas-details">
                                                        <p></p>
                                                        <a href="#" class="read-more"></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.End of masonry item -->
                                        </div></div></div></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.End of news masonry -->
            <div class="page-content" style="transform: none;">
                <div  style="transform: none;">
                    <div class="row" style="transform: none;">
                        <div class="hidden-xs hidden-sm col-md-2 leftSidebar" style="position: relative; overflow: visible; box-sizing: border-box; min-height: 1px;">
                            
                            <!-- /.End of trending post -->
                            
                            <!-- /.End of banner content -->
                        <div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 1px; position: static; transform: none; top: 0px; left: 189.6px;"><div class="trending-post">
                                <div class="title-holder">
                                    <h3 class="title">Recent Docs</h3>
                                    <span class="title-shape title-shape-dark"></span>
                                </div>
                                <!--  /.End of title -->
                                <?php foreach($files as $file) : ?>
                                <div class="single-post">
                                   <h4><a href="#"><?php echo $file['title'];?></a></h4>
                                    <img src="http://bisnis.financialsecurity.id/assets/learning/<?= $file['img'];?>" width='120px'>
                                   <div class="entry-meta">
                                    <a href="http://bisnis.financialsecurity.id/assets/learning/<?= $file['file'];?>"> <img src="http://bisnis.financialsecurity.id/assets/img/down.png" width="128px"></a>
                                    </div>
                                     <div class="entry-meta">
                                        <span class="comment-link"><a href="#"><i class="fa fa-comment-o" aria-hidden="true"></i><?= date("d-M-Y", strtotime($file['created_at']));?></a></span>
                                    </div>
                                </div>
                                 <?php endforeach ?>
                                <div class="single-post">
                
                                  <a href="material/seemorefiles/A">See More</a>
                                </div>
                            </div><div class="resize-sensor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div class="resize-sensor-expand" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; transition: all 0s ease 0s; width: 205px; height: 978px;"></div></div><div class="resize-sensor-shrink" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0; top: 0; transition: 0s; width: 200%; height: 200%"></div></div></div></div></div>
                        <main class="col-xs-12 col-sm-5 col-md-7 content p_r_40" style="position: relative; overflow: visible; box-sizing: border-box; min-height: 1px;">
                            
                            <!-- /.End of grid post -->
                            
                            <!-- /.End of media post -->
                            
                            <!-- /.End of media post -->
                            
                            <!-- /.End of media post -->
                            
                            <!-- /.End of media post -->
                            
                            <!-- /.End of media post -->
                            
                            <!-- /.End of media post -->
                            
                            <!-- /.End of media post -->
                            <!--                            <div class="loadmore_block"> 
                                                            <a href="#" class=""> Load More</a> 
                                                        </div>-->
                            <!-- /.End of Load more -->
                            
                            <!-- /.End of pagination -->
                        <div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 1px; position: static; transform: none;"><article class="grid_post grid_post_lg text-center">
                                <figure>
                                    
                                <div class="item vide_post_item">
                                    <!-- the class "videoWrapper169" means a 16:9 aspect ration video. Another option is "videoWrapper43" for 4:3. -->
                                    <div class="videoWrapper videoWrapper169 js-videoWrapper">
                                      
                                       <br>
                                       <br>
                                       <br>
                                      <figure><iframe class="videoIframe js-videoIframe" src="https://www.youtube.com/embed/g3YlIlIIjWg" width="600" height="315"   frameborder="0" allow="autoplay; encrypted-media" allowfullscreen ></iframe></figure>
                                    </div>
                                    <!--<button onclick="videoStop()">external close button</button>-->
                                </div>
                                    <figcaption>
                                        <div class="post-cat"><span></span> <a href="#">Fire Truck, Excavator, Train, Garbage Truck, Police Cars & Tractor | LEGO Construction Toy Vehicles</a></div>
                                        <div class="entry-meta">
                                            
                                        </div>
                                        
                                    </figcaption>
                                </figure>
                            </article><div class="resize-sensor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div class="resize-sensor-expand" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; transition: all 0s ease 0s; width: 692px; height: 2870px;"></div></div><div class="resize-sensor-shrink" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0; top: 0; transition: 0s; width: 200%; height: 200%"></div></div></div></div></main>
                        <aside class="col-xs-12 col-sm-4 col-md-3 rightSidebar" style="position: relative; overflow: visible; box-sizing: border-box; min-height: 1px;">
                            
                            <!-- /.End of latest post -->
                            
                            <!-- /.End of subscribe -->
                            
                            <!-- /.End of banner content -->
                            
                            <!-- /.End of category widget -->
                        <div  style="padding-top: 0px; padding-bottom: 1px; position: static; transform: none; top: 0px; left: 1067.1px;"><div class="latest_post_widget">
                                <div class="title-holder">
                                    <h3 class="title">Recent Videos</h3>
                                    <span class="title-shape title-shape-dark"></span>
                                </div>
                                <!--  /.End of title -->
                                <?php foreach($videos as $video) : ?>
                                <div class="media latest_post">
                                   
                                    <div class="media-body">
                                      <figure><iframe src="https://www.youtube.com/embed/<?= $video['url']; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen ></iframe></figure>
                                        <h6 class="media-heading"><a href="#"><?= $video['title']; ?></a></h6>
                                        <div class="entry-meta">
                                            <span class="entry-date"><i class="fa fa-calendar-o" aria-hidden="true"></i><time datetime="2018-01-21T19:00"><?= date("d-M-Y", strtotime($video['created_at']));?></time></span>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach ?>
                                <!-- /.latest post -->
                                
                                
               
                
                <div class="media latest_post">
                                    <a href="material/seemorevideos/A">See More</a>
                                </div>
                                <!-- /.latest post -->
                            </div>
                                <!-- /.End of category -->
                            <div class="resize-sensor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div class="resize-sensor-expand" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; transition: all 0s ease 0s; width: 303px; height: 1212px;"></div></div><div class="resize-sensor-shrink" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0; top: 0; transition: 0s; width: 200%; height: 200%"></div></div></div></div></aside>
                    </div>
                </div>
                <div class=" container">
                    <div class="height_15"></div>
                   
                </div>

                <!--  /.End of youtube video -->

</div>
